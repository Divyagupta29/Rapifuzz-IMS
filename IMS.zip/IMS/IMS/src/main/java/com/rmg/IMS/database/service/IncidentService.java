package com.rmg.IMS.database.service;

import com.rmg.IMS.model.UserIncident;

public interface IncidentService {
    void save(UserIncident userIncident);

    void updateStatus(String incidentStatus, String incidentId);

    void updateIncident(String priority, String incidentDetail, String incidentId);

    UserIncident findByIncidentId(String incidentId);
}
