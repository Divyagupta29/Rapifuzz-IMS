package com.rmg.IMS.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rmg.IMS.request.ForgotPasswordRequest;
import com.rmg.IMS.request.LoginRequest;
import com.rmg.IMS.request.UserDetailsResquest;
import com.rmg.IMS.request.UserIncidentRequest;
import com.rmg.IMS.request.updateIncidentRequest;
import com.rmg.IMS.response.CommanResponse;
import com.rmg.IMS.response.GetIncidentResponse;
import com.rmg.IMS.service.ImgService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ImgController {
	
	@Autowired
	private ImgService imgService;
	

	
	@PostMapping("user/registration")
	public CommanResponse addUser(@RequestBody UserDetailsResquest userDetailsResquest) {
       return imgService.addUser(userDetailsResquest);
	}
	
	@GetMapping("user/login")
	public CommanResponse loginUser(@RequestBody LoginRequest loginResquest) {
       return imgService.loginUser(loginResquest);
	}
	
	@PostMapping("add/incident")
	public CommanResponse addIncident(@RequestBody UserIncidentRequest request) {
		return imgService.addIncident(request);
	}
	
	@PostMapping("forgot/password")
	public CommanResponse forgotPassword(@RequestBody ForgotPasswordRequest request) {
		return imgService.forgotPassword(request);
	}
	
	@GetMapping("/Get/incident/{incidentId}")
	public GetIncidentResponse getIncidentDetail(@PathVariable("incidentId") String incident_id) {
	    return imgService.GetIncidentDetail(incident_id);
	}
	
	@PostMapping("update/incident")
	public GetIncidentResponse updateIncidentDetail(@RequestBody updateIncidentRequest request ) {
		return imgService.updateIncidentDetail(request);
	}
	

}
