package com.rmg.IMS.database.service;

import com.rmg.IMS.model.UserIncident;
import com.rmg.IMS.repository.IncidentDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class IncidentServiceImpl implements IncidentService {

    @Autowired
    private IncidentDetailRepository incidentDetailRepository;

    @Override
    @Transactional
    public void save(UserIncident userIncident) {
        incidentDetailRepository.save(userIncident);
    }

    @Override
    @Transactional
    public void updateStatus(String incidentStatus, String incidentId) {
        incidentDetailRepository.updateStatus(incidentStatus, incidentId);
    }

    @Override
    @Transactional
    public void updateIncident(String priority, String incidentDetail, String incidentId) {
        incidentDetailRepository.updateIncidentDetail(priority, incidentDetail, incidentId);
    }

    @Override
    public UserIncident findByIncidentId(String incidentId) {
        return incidentDetailRepository.findByIncidentId(incidentId);
    }
}
